---
name: Campus Pulse
colors:
  surface: '#121319'
  surface-dim: '#121319'
  surface-bright: '#383940'
  surface-container-lowest: '#0d0e14'
  surface-container-low: '#1a1b22'
  surface-container: '#1e1f26'
  surface-container-high: '#292930'
  surface-container-highest: '#34343b'
  on-surface: '#e3e1eb'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e3e1eb'
  inverse-on-surface: '#2f3037'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#c3c0ff'
  on-secondary: '#1d00a5'
  secondary-container: '#3626ce'
  on-secondary-container: '#b3b1ff'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#121319'
  on-background: '#e3e1eb'
  surface-variant: '#34343b'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system defines an electric, high-energy, dark-first ecosystem built for collegiate event discovery, campus culture, and student-driven social velocity. It balances late-night campus spirit with frictionless, reliable utility for student leaders, campus organizations, and university administrators.

### Core Character
- **Electric & Immersive:** Deep obsidian backgrounds paired with vivid luminous neon tones create an after-hours festival atmosphere while keeping functional data crisp and immediate.
- **Dynamic & Hyper-Contextual:** Adapts instantaneously across user personas—freshmen seeking clubs, Greek life directors, student government event organizers, and university compliance administrators.
- **Expressive Glassmorphism:** Layered frosted glass panels, translucent floating chrome, and spectral glow boundaries emulate contemporary high-performance mobile interfaces.

### Aesthetic Stance
The aesthetic leans into a refined **Cyber-Campus Glassmorphism** archetype: precision-engineered typography anchored by deep ambient shadows, optical violet glows, micro-sheen edge borders, and vibrant status accents.

## Colors

The palette is anchored in an ultra-deep space-black foundation (`#090A10`) that allows high-energy luminous spectrums to punch through cleanly without generating glare or eye fatigue.

### Palette Architecture
- **Primary (Electric Violet - `#8B5CF6`):** The primary interaction hue. Used for interactive states, key focal actions, selected pills, brand badges, and glowing highlights.
- **Secondary (Deep Indigo - `#4F46E5`):** Structural anchor. Used for ambient glow gradations, interactive state hover shifts, secondary navigation triggers, and structural visual emphasis.
- **Tertiary (Cyber Emerald - `#10B981`):** Operational confidence. Denotes active RSVPs, open spots, verified campus organization credentials, live events, and positive delta metrics.
- **Accent Coral (`#F97316`):** Urgent energy. Highlights limited-capacity countdowns, trending live stages, alerts, and pending action items.
- **Neutral Surface Palette:**
  - Base Obsidian: `#090A10`
  - Elevated Container / Glass Tint: `rgba(20, 22, 36, 0.72)`
  - High-Surface Card: `rgba(29, 32, 54, 0.85)`
  - Border Sheen: `rgba(255, 255, 255, 0.08)`
  - Active Glow Stroke: `rgba(139, 92, 246, 0.35)`
  - Text Primary: `#F8FAFC`
  - Text Secondary: `#94A3B8`
  - Text Muted: `#64748B`

## Typography

The typography leverages **Plus Jakarta Sans** for headlines and display tiers, imparting a contemporary, friendly, and energetic cadence with modern geometric proportions. **Inter** handles high-density event cards, administrative tables, metadata, and form inputs, guaranteeing extreme legibility across micro screens and busy feeds.

### Hierarchy & Treatment
- **Display & Large Headlines:** Styled with negative tracking (`-0.03em` to `-0.015em`) and high contrast weights (700-800) to anchor event cards and hero banners.
- **Labels & Micro-Badges:** Uppercase or high-weight medium styles with slight positive tracking (`0.02em` to `0.04em`) to maintain legibility on illuminated chip backgrounds and status markers.
- **Mobile Graceful Degradation:** Use `headline-xl-mobile` and `headline-lg-mobile` dynamically below 640px breakpoints to preserve line wraps on event titles.

## Layout & Spacing

The platform is designed around a responsive 12-column grid layout on desktop, collapsing to an 8-column layout on tablet, and a single or 2-column stacked fluid layout on mobile devices.

### Breakpoints & Layout Adaptations
- **Desktop (>= 1280px):** 12-column grid, 1280px max-width content container, fixed-fluid glass navigation bar docked to the top, side-docked administrative filters, `margin: 2rem`, `gutter: 1.5rem`.
- **Tablet (768px - 1279px):** 8-column grid, compact header, collapsible search drawer, `margin: 1.5rem`, `gutter: 1rem`.
- **Mobile (< 768px):** Fluid 4-column flow with continuous vertical feed, fixed bottom glass action bar for thumb-zone discoverability, top persistent mini-bar housing active Role and User switchers, `margin-mobile: 1rem`, `gutter-mobile: 1rem`.

### Rhythmic Rules
All component padding, cards, and flex intervals align strictly to multiples of `0.25rem` (4px). Structural sections utilize `space-xl` (40px) vertical separations to ensure distinct conceptual partitioning between live feeds, trending clusters, and analytics cards.

## Elevation & Depth

Visual depth is achieved through translucent frosted layering, ambient luminescence, and subtle light-sheen perimeter strokes rather than murky physical drop shadows.

### Elevation Hierarchy
1. **Canvas Base (Level 0):** Pure dark background (`#090A10`), occasionally highlighted by muted non-intrusive radial gradients of electric indigo (`rgba(79, 70, 229, 0.08)`) and violet in header areas.
2. **Surface Glass (Level 1 - Cards, Event Tiles):** Semi-transparent obsidian fill `rgba(20, 22, 36, 0.75)` with `backdrop-filter: blur(16px)` and a `1px` inner boundary stroke of `rgba(255, 255, 255, 0.07)`.
3. **Elevated Floating UI (Level 2 - Navigation Bar, Modals, Menus):** `rgba(29, 32, 54, 0.85)` with `backdrop-filter: blur(24px)`, outer diffused glow `0 12px 32px -4px rgba(0, 0, 0, 0.65)`, and accent edge stroke `rgba(139, 92, 246, 0.2)`.
4. **Hero & Hover Glows (Interactive Focus):** Key CTA buttons, live badges, and active RSVP selections cast a localized luminous halo: `0 0 20px rgba(139, 92, 246, 0.35)`.

## Shapes

The design system adopts a balanced, tactile geometry (`roundedness: 2`). Base containers, modal surfaces, and event banners feature a modern 8px (`0.5rem`) to 16px (`1rem`) border radius, while badges, interactive chips, tag filters, and role switchers utilize full pill geometries (`rounded-full` / `9999px`) to emphasize touch-friendly interactivity.

### Structural Radius Scale
- **Interactive Controls (Inputs, Standard Buttons):** `rounded-md` (0.5rem / 8px).
- **Cards, Drawers, Flyout Modals:** `rounded-lg` (1rem / 16px) or `rounded-xl` (1.5rem / 24px) for expansive hero canvas cards.
- **Pills, Role Switchers, Live Tags, Avatars:** Pill radius (`9999px`) for seamless capsule geometry.

## Components

### Glassmorphic Navigation Bar
- **Structure:** Floating frosted bar with `backdrop-filter: blur(20px)`, dark translucent background, and a hairline bottom/perimeter sheen.
- **Integrated Switchers:** 
  - *Role Switcher:* Compact pill segment control allowing instantaneous toggling between "Student", "Club Officer", and "Campus Admin".
  - *User ID Selector:* Glass dropdown displaying current campus avatar, student ID handle, and organization affiliation badge with quick-switch capability for demoing different permission levels.

### Quick RSVP Cards
- **Geometry:** Elevated glass container with a media header (event banner with aspect ratio 16:9), live dynamic status badge (e.g., "Happening Tonight", "Spots Left: 14"), title, campus venue tags, and participant avatar pile.
- **Action State:** Prominent 1-click Quick RSVP button with micro-sheen border that shifts dynamically from outlined purple to solid neon violet with a tertiary emerald checkmark once confirmed.

### Pill Badges & Filter Chips
- **Aesthetic:** Fully rounded pill capsules.
- **Variants:**
  - *Category Pills (Music, Tech, Greek Life, Sports):* Semi-transparent dark surface with soft border, turning into solid neon-tinted background on toggle.
  - *Live State Badges:* Coral or emerald translucent pill with a pulsing 6px neon dot indicator.

### Organizer Event Creation Panel / Modals
- **Layout:** Centered modal on desktop, full-screen bottom sheet on mobile with backdrop blur.
- **Inputs:** Dark field inputs (`rgba(15, 17, 28, 0.8)`) with `1px` border of `rgba(255, 255, 255, 0.1)`, shifting to electric violet border with ambient glow on `:focus`.
- **Form Controls:** Step indicator pills, date-time selector with dark calendar dropdown, venue auto-complete, and instant card preview.

### Admin Metrics & Report Tiles
- **Aesthetic:** Modular 4-column glass stat cards displaying campus engagement velocity, total check-ins, active RSVP rate, and club budget utilization.
- **Data Accents:** Neon emerald trend badges (`+24% this week`), glowing Sparkline SVG overlays, and clean tabular lists with low-contrast borders between rows.

### Checkboxes, Radios, & Switches
- **Form Elements:** Custom styled controls filled with dark substrate; checked state displays vibrant electric violet or emerald fills with high-contrast white tick marks and smooth spring transition animations.